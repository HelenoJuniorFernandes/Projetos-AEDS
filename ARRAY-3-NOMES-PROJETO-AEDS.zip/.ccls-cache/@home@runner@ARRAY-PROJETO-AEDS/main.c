
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
  //DECLARAÇÃO DE UM ARRAY DE STRINGS PARA ARMAZENAR TRES NOMES
  char nomes[3][30]; //Supondo nomes com até 30 caracteres
  //solicitar ao usuário que digite os nomes
  for (int i = 0; i < 3; i++) {
    printf("Digite %d° nome: ", i + 1);
    scanf("%s", nomes[i]);
  }

  //imprimir os nomes em ordem inversa
  printf("\nNomes em ordem inversa:\n");
  for (int i = 2; i >= 0; i--) {
    printf("%s\n", nomes[i]);
  }
//imprimir os nomes e seus comprimentos
  printf("\nNomes e seus comprimentos:\n");
  for (int i = 0; i < 3; i++) {
    printf("%s - Comprimento: %zu\n", nomes[i], strlen(nomes[i]));
  //%zu é usado para imprimir valores de tipo s:
    //ele é particulamente util quando voce esta trabalhando com funcoes que retornam valores
    //como strlen, que retorna o comprimento de uma string
  }
  return 0;
}
  
  
  
  